export { default as Timer } from "components/Timer/Timer";
