npm i react-bootstrap bootstrap typescript @reduxjs/toolkit

사용된 패키지

1. css디자인을 위한 bootstrap
2. Typescript와 redux-toolkit (CRA시 설치하지 못했을 경우)
   npm i typescript @reduxjs/toolkit

npm i npm start 시 필요한 패키지들을 자동으로 받습니다.
